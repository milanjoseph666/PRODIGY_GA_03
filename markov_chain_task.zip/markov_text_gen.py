
import random

class MarkovChainTextGenerator:
    def __init__(self):
        self.model = {}

    def train(self, text, n=1):
        words = text.split()
        for i in range(len(words) - n):
            key = tuple(words[i:i+n])
            next_word = words[i+n]
            if key not in self.model:
                self.model[key] = []
            self.model[key].append(next_word)

    def generate(self, length=50, seed=None):
        if not self.model:
            return ""

        if seed is None or tuple(seed.split()) not in self.model:
            seed = random.choice(list(self.model.keys()))
        else:
            seed = tuple(seed.split())

        output = list(seed)
        for _ in range(length - len(seed)):
            next_words = self.model.get(seed, [])
            if not next_words:
                break
            next_word = random.choice(next_words)
            output.append(next_word)
            seed = tuple(output[-len(seed):])

        return ' '.join(output)


if __name__ == "__main__":
    sample_text = (
        "Artificial intelligence is the simulation of human intelligence processes by machines, "
        "especially computer systems. These processes include learning, reasoning, and self-correction."
    )
    
    generator = MarkovChainTextGenerator()
    generator.train(sample_text, n=1)
    generated_text = generator.generate(length=30)
    print("Generated Text:\n", generated_text)
