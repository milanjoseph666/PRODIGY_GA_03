
# Text Generation with Markov Chains

## Description
This project implements a simple text generation algorithm using Markov Chains. It builds a statistical model that predicts the next word based on the current one(s).

## How to Run
1. Make sure you have Python installed.
2. Run the script `markov_text_gen.py` using:
   ```bash
   python markov_text_gen.py
   ```

## Features
- Trains a Markov chain model from a given input text
- Generates random text using the trained model

## References
- Ref: #1, #2 (as mentioned in the task prompt)
